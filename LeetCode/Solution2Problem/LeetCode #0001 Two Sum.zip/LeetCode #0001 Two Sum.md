
[TOC]

#[LeetCode #0001 Two Sum](https://leetcode.com/problems/two-sum/)

**Java 知识点** —— `初始化`
```java
// 一维数组的初始化
int[] solution = new int[2];

int[] nums1 = new int[]{2, 7, 11, 15};
```

**Java 知识点** —— `HashMap`
```java
Map<Integer, Integer> map = new HashMap<>();

Integer  val = map.get(nums[i]);  // value = map.get(key)

map.put(target - nums[i], i); // map.put(key, value)
```



( `?` ) 什么要用`HashMap`?
> `HashMap`：基于哈希表的 Map 接口的实现。此实现提供所有可选的映射操作，并允许使用 null 值和 null 键。（除了非同步和允许使用 null 之外，HashMap 类与 Hashtable 大致相同。）此类不保证映射的顺序，特别是它不保证该顺序恒久不变。 此实现假定哈希函数将元素适当地分布在各桶之间，可为基本操作（get 和 put）提供稳定的性能。迭代 collection 视图所需的时间与 HashMap 实例的“容量”（桶的数量）及其大小（键-值映射关系数）成比例。所以，如果迭代性能很重要，则不要将初始容量设置得太高（或将加载因子设置得太低）。


```java
package LeetCode;

import java.util.HashMap;
import java.util.Map;

class Solution
{
    public int[] twoSum(int[] nums, int target)
    {
        Map<Integer, Integer> map = new HashMap<>();

        for(int i = 0; i < nums.length; i++)
        {
            Integer  val = map.get(nums[i]);  // value = map.get(key)
            if(val != null)
            {
                return new int[]{val, i};
            }
            else
            {
                // {2,7,11,15};
                map.put(target - nums[i], i); // map.put(key, value)
                // {9-2, 0} 意思是，7这个数字如果作为key出现了，它所匹配的值就是配对为target的值的索引。
            }
        }
        return null;
    }
}
public class LeetCode0001 {
    public static void main(String[] args) {
        // TODO code application logic here
        int[] nums1 = new int[]{2, 7, 11, 15};
        int target1 = 9;
        
        int[] nums2 = new int[]{3, 2, 4};
        int target2 = 6;
        
        int[] nums3 = new int[]{3, 3};
        int target3 = 6;
        
        Solution sol = new Solution();
        int[] result =  sol.twoSum(nums3, target3);
            
        System.out.println(result[0] + " " + result[1]);
    }
    
}

```

> **解题过程分析**：
> 设想target是目标，target由数组中的`两个数`相加得到。
> `数1` 和 `数2` 暂且称为互补的数。
> 答案要的是这两个数的`索引值`（即数组中的下标）。
>- **【情况1】**使用HashMap，键存放`数1`，值存放`数2的索引`。遍历到`数1`的时候，由`i`标识，此时返回`i`和`数2的索引`（键为`数1`时对应的`值`）即构成答案。
>- **【情况2】**HashMap如果找到的键对应的值为null，说明两种可能：①这个值没有互补的数，②这个值的互补数还没加入HashMap. 这两种情况可以统一处理。即，将该值的互补数计算出来，然后按照**【情况1】**进行操作。